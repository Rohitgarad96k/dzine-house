import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import ReadyToStart from '../components/ReadyToStart';
import { digitalServices, digitalProcess, digitalPackages, digitalFaqs } from '../data/data';

// --- Custom Scroll Animation Engine ---
function FadeInView({ children, delay = 0, direction = 'up' }) {
  const [isVisible, setIsVisible] = useState(false);
  const domRef = useRef();

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    if (domRef.current) observer.observe(domRef.current);
    return () => observer.disconnect();
  }, []);

  const startTranslate = 
    direction === 'up' ? 'translate-y-16' : 
    direction === 'left' ? 'translate-x-12' : 
    direction === 'right' ? '-translate-x-12' : 'translate-y-0';

  return (
    <div
      ref={domRef}
      className={`transform transition-all duration-1000 ease-out ${
        isVisible ? 'opacity-100 translate-y-0 translate-x-0' : `opacity-0 ${startTranslate}`
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

export default function DigitalPage() {
  const [isMounted, setIsMounted] = useState(false);
  const [activeProcess, setActiveProcess] = useState(digitalProcess[0].id);
  const [openFaq, setOpenFaq] = useState(null);

  useEffect(() => {
    const timeout = setTimeout(() => setIsMounted(true), 100);
    return () => clearTimeout(timeout);
  }, []);

  const toggleFaq = (index) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  return (
    <main className="font-sans bg-gray-50 min-h-screen">
      
      {/* 1. High-Tech Hero Banner */}
      <section className="relative bg-[#0B1120] py-32 overflow-hidden flex items-center justify-center min-h-[50vh]">
        {/* Animated Grid Background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f2937_1px,transparent_1px),linear-gradient(to_bottom,#1f2937_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20"></div>
        {/* Glowing Orbs */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-teal-600 rounded-full mix-blend-screen filter blur-[120px] opacity-30 animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600 rounded-full mix-blend-screen filter blur-[120px] opacity-20 animate-pulse animation-delay-2000"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 text-center text-white">
          <div className={`inline-block mb-6 px-4 py-1.5 rounded-full border border-teal-500/30 bg-teal-500/10 text-teal-300 text-sm font-bold tracking-widest uppercase transition-all duration-1000 ease-out ${isMounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            Next-Gen Digital Experiences
          </div>
          <h1 className={`text-4xl md:text-6xl lg:text-7xl font-extrabold tracking-tight drop-shadow-2xl transition-all duration-1000 delay-150 ease-out ${isMounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            Digital & <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-400 to-blue-500">UI/UX Design</span>
          </h1>
          <p className={`mt-8 text-gray-400 font-bold tracking-widest uppercase text-sm md:text-base transition-all duration-1000 delay-300 ease-out ${isMounted ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
            <Link to="/" className="hover:text-teal-400 transition-colors">Home</Link> <span className="mx-2">/</span> Digital
          </p>
        </div>
      </section>

      {/* 2. Overview Section */}
      <section className="py-24 text-center bg-white border-b border-gray-200">
        <FadeInView delay={0}>
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-6 uppercase tracking-tight">
              Design That <span className="text-teal-600">Drives Action</span>
            </h2>
            <div className="w-24 h-1 bg-teal-500 mx-auto mb-8 rounded"></div>
            <p className="text-gray-600 text-lg md:text-xl leading-relaxed">
              We live in a digital-first world. An outdated app or a confusing website isn't just an eyesore—it costs you revenue. We combine deep user psychology with stunning visual aesthetics to build digital products that users love and competitors envy.
            </p>
          </div>
        </FadeInView>
      </section>

      {/* 3. Deep Dive Services (Zig-Zag) */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {digitalServices.map((service, index) => (
            <div key={service.id} className="mb-32 last:mb-0 relative">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                
                {/* Text Content */}
                <FadeInView delay={100} direction={index % 2 === 0 ? 'right' : 'left'}>
                  <div className={`order-2 ${index % 2 === 0 ? 'lg:order-1' : 'lg:order-2'}`}>
                    <div className="w-16 h-16 bg-teal-100 rounded-2xl flex items-center justify-center text-teal-600 font-black text-2xl mb-6 shadow-sm">
                      0{index + 1}
                    </div>
                    <h3 className="text-3xl md:text-4xl font-extrabold text-gray-900 mb-6 tracking-tight">
                      {service.title}
                    </h3>
                    <p className="text-gray-600 text-lg leading-relaxed mb-8">
                      {service.description}
                    </p>
                    
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start text-gray-800 font-semibold bg-white p-4 rounded-xl border border-gray-100 shadow-sm hover:border-teal-300 transition-colors">
                          <svg className="w-5 h-5 text-teal-500 mr-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                          {feature}
                        </li>
                      ))}
                    </ul>

                    <Link 
                      to={`/contact?service=${encodeURIComponent(service.title)}`} 
                      className="inline-flex items-center px-8 py-4 bg-gray-900 text-white font-extrabold text-sm uppercase tracking-widest rounded-xl hover:bg-teal-600 hover:shadow-xl transition-all duration-300 group"
                    >
                      {service.btnText}
                      <svg className="w-5 h-5 ml-3 transform group-hover:translate-x-2 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14 5l7 7m0 0l-7-7m7-7H3" />
                      </svg>
                    </Link>
                  </div>
                </FadeInView>

                {/* Image Mockup */}
                <FadeInView delay={300} direction={index % 2 === 0 ? 'left' : 'right'}>
                  <div className={`order-1 ${index % 2 === 0 ? 'lg:order-2' : 'lg:order-1'}`}>
                    <div className="relative aspect-square lg:aspect-[4/3] bg-gray-200 rounded-3xl overflow-hidden shadow-2xl group border-8 border-white">
                      <div className="absolute inset-0 bg-gradient-to-t from-gray-900/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10"></div>
                      <img 
                        src={service.image} 
                        alt={service.title} 
                        className="w-full h-full object-cover transform transition-transform duration-1000 group-hover:scale-105"
                      />
                    </div>
                  </div>
                </FadeInView>

              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Mid-Page Lead Magnet (Free Audit) */}
      <section className="py-20 bg-teal-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] mix-blend-overlay"></div>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <FadeInView delay={0}>
            <h2 className="text-3xl md:text-5xl font-extrabold text-white mb-6">Is Your Website Losing Customers?</h2>
            <p className="text-teal-100 text-lg md:text-xl mb-10 max-w-2xl mx-auto font-medium">
              Book a free 15-minute discovery call. We will review your current website or app UI and give you 3 actionable steps to improve conversions today.
            </p>
            <Link to="/contact?inquiry=Free-UX-Audit" className="inline-block px-10 py-4 bg-white text-teal-700 font-extrabold text-lg uppercase tracking-widest rounded-full shadow-2xl hover:bg-gray-50 hover:-translate-y-1 transition-all duration-300">
              Claim Free UX Audit
            </Link>
          </FadeInView>
        </div>
      </section>

      {/* 5. Interactive Process Stepper */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeInView delay={0}>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-extrabold text-gray-900 uppercase">Our Digital Process</h2>
              <div className="w-24 h-1 bg-teal-500 mx-auto mt-4 mb-6 rounded"></div>
              <p className="text-gray-600 text-lg">We leave nothing to chance. Our proven framework ensures every pixel serves a purpose.</p>
            </div>
          </FadeInView>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            {/* Step Selectors */}
            <div className="md:col-span-4 flex flex-col gap-3">
              {digitalProcess.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveProcess(item.id)}
                  className={`flex items-center text-left p-4 rounded-xl border-l-4 transition-all duration-300 ${
                    activeProcess === item.id 
                      ? 'bg-teal-50 border-teal-600 shadow-md transform translate-x-2' 
                      : 'bg-white border-transparent text-gray-500 hover:bg-gray-50'
                  }`}
                >
                  <span className={`text-2xl font-black mr-4 ${activeProcess === item.id ? 'text-teal-600' : 'text-gray-300'}`}>
                    {item.step}
                  </span>
                  <span className={`font-bold text-lg ${activeProcess === item.id ? 'text-gray-900' : ''}`}>
                    {item.title}
                  </span>
                </button>
              ))}
            </div>

            {/* Step Details Display */}
            <div className="md:col-span-8 bg-gray-900 rounded-3xl p-8 md:p-12 text-white shadow-2xl min-h-[250px] flex items-center relative overflow-hidden">
               {/* Decorative Background abstract */}
               <svg className="absolute -bottom-24 -right-24 w-96 h-96 text-gray-800 opacity-50" fill="currentColor" viewBox="0 0 100 100"><path d="M50 0C22.4 0 0 22.4 0 50s22.4 50 50 50 50-22.4 50-50S77.6 0 50 0zm0 80c-16.6 0-30-13.4-30-30s13.4-30 30-30 30 13.4 30 30-13.4 30-30 30z"/></svg>
               
               {digitalProcess.map((item) => (
                  activeProcess === item.id && (
                    <div key={item.id} className="relative z-10 animate-[fadeIn_0.4s_ease-out]">
                      <div className="text-teal-400 font-black text-6xl mb-6 opacity-50">Step {item.step}</div>
                      <h3 className="text-3xl md:text-4xl font-extrabold mb-6">{item.title}</h3>
                      <p className="text-gray-300 text-lg md:text-xl leading-relaxed max-w-2xl">
                        {item.desc}
                      </p>
                    </div>
                  )
               ))}
            </div>
          </div>
        </div>
      </section>

      {/* 6. Digital Packages / Pricing */}
      <section className="py-24 bg-gray-50 border-t border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeInView delay={0}>
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="text-3xl md:text-5xl font-extrabold tracking-tight uppercase text-gray-900">
                Digital <span className="text-teal-600">Packages</span>
              </h2>
              <p className="mt-4 text-gray-600 text-lg">Scalable solutions to digitize your business.</p>
            </div>
          </FadeInView>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
            {digitalPackages.map((pkg, index) => (
              <FadeInView key={pkg.name} delay={index * 200} direction="up">
                <div className={`relative p-8 rounded-3xl bg-white flex flex-col h-full transition-transform duration-300 ${
                  pkg.isPopular ? 'border-2 border-teal-500 shadow-2xl md:-translate-y-4' : 'border border-gray-200 shadow-md hover:border-teal-300'
                }`}>
                  
                  {pkg.isPopular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <span className="bg-teal-600 text-white text-xs font-extrabold uppercase tracking-widest py-2 px-6 rounded-full shadow-lg">
                        Best Value
                      </span>
                    </div>
                  )}

                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-gray-500 text-sm h-10 mb-6">{pkg.description}</p>
                  <div className="text-4xl font-extrabold text-teal-600 mb-8 border-b border-gray-100 pb-8">
                    {pkg.price}
                  </div>

                  <ul className="space-y-4 mb-10 flex-grow">
                    {pkg.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start text-gray-700 font-medium text-sm">
                        <svg className="w-5 h-5 text-teal-500 mr-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <Link 
                    to={`/contact?package=${encodeURIComponent(pkg.name)}`} 
                    className={`w-full text-center py-4 rounded-xl font-extrabold uppercase tracking-widest transition-all duration-300 ${
                      pkg.isPopular 
                        ? 'bg-teal-600 text-white hover:bg-teal-700 shadow-lg' 
                        : 'bg-gray-100 text-teal-700 hover:bg-teal-50 hover:border-teal-500 border border-transparent'
                    }`}
                  >
                    Select Package
                  </Link>
                </div>
              </FadeInView>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Interactive Digital FAQs */}
      <section className="py-24 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <FadeInView delay={0}>
            <div className="text-center mb-16">
              <h2 className="text-3xl font-extrabold text-gray-900 uppercase">Digital FAQs</h2>
              <div className="w-16 h-1 bg-teal-500 mx-auto mt-4 rounded"></div>
            </div>
          </FadeInView>

          <div className="space-y-4">
            {digitalFaqs.map((faq, index) => (
              <FadeInView key={index} delay={index * 100} direction="up">
                <div 
                  className={`bg-gray-50 border rounded-xl overflow-hidden transition-all duration-300 ${openFaq === index ? 'border-teal-500 bg-white shadow-md' : 'border-gray-200 hover:border-teal-300'}`}
                >
                  <button 
                    onClick={() => toggleFaq(index)}
                    className="w-full px-8 py-6 text-left flex justify-between items-center focus:outline-none"
                  >
                    <span className={`font-bold text-lg pr-8 ${openFaq === index ? 'text-teal-600' : 'text-gray-900'}`}>
                      {faq.question}
                    </span>
                    <svg 
                      className={`w-6 h-6 transform transition-transform duration-300 text-teal-500 shrink-0 ${openFaq === index ? 'rotate-180' : ''}`} 
                      fill="none" viewBox="0 0 24 24" stroke="currentColor"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  
                  <div 
                    className={`transition-all duration-300 ease-in-out ${openFaq === index ? 'max-h-64 opacity-100' : 'max-h-0 opacity-0'}`}
                  >
                    <div className="px-8 pb-6 text-gray-600 border-t border-gray-100 pt-4 leading-relaxed">
                      {faq.answer}
                    </div>
                  </div>
                </div>
              </FadeInView>
            ))}
          </div>
        </div>
      </section>

      <ReadyToStart />
    </main>
  );
}