import React from 'react';
import Hero from '../components/Hero';
import CoreCapabilities from '../components/CoreCapabilities';
import CreativeServices from '../components/CreativeServices';
import WhyTrustUs from '../components/WhyTrustUs';
import SignatureWork from '../components/SignatureWork'; // Add this import
import PricingTable from '../components/PricingTable';
import CreativeProcess from '../components/CreativeProcess';
import MonthlyRetainer from '../components/MonthlyRetainer';
import IndustriesGrid from '../components/IndustriesGrid';
import BlogInsights from '../components/BlogInsights';
import ReadyToStart from '../components/ReadyToStart';

export default function HomePage() {
  return (
    <main>
      <Hero />
      <CoreCapabilities />
      <CreativeServices />
      <WhyTrustUs />
      
      
      <SignatureWork /> 
      
      <CreativeProcess /> 
      <MonthlyRetainer />
      <IndustriesGrid />
      <PricingTable />
      <BlogInsights />
      <ReadyToStart />
    </main>
  );
}